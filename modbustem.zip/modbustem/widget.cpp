#include "widget.h"
#include "ui_widget.h"

#include <QModbusRtuSerialMaster>
#include <QModbusDataUnit>
#include <QModbusReply>

#include <QMessageBox>
#include <QVariant>
#include <QSerialPort>
#include <QDebug>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonParseError>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    this->setWindowTitle("智能电梯系统");

    modbusDevic = new QModbusTcpClient(this);
    if(modbusDevic->state()!=QModbusDevice::ConnectedState)
    {
        modbusDevic->setConnectionParameter(QModbusDevice::NetworkPortParameter,9000);
        modbusDevic->setConnectionParameter(QModbusDevice::NetworkAddressParameter,"192.168.1.100");
        modbusDevic->connectDevice();

    }
    else
    {
        modbusDevic->disconnectDevice();
    }




    timer = new QTimer();
    connect(timer,&QTimer::timeout,this,&Widget::timerSLot);
    timer->start(1000);

    m_timer=new QTimer(this);
    m_timer->setInterval(1000);

    connect(m_timer,&QTimer::timeout,this,&Widget::on_timerTimeout);

    a_timer=new QTimer(this);
    a_timer->setInterval(3000);

    connect(a_timer,&QTimer::timeout,this,&Widget::on_timerupload);

    QHostAddress m_address("iq0vkon4zrV.iot-as-mqtt.cn-shanghai.aliyuncs.com");
    client = new QMQTT::Client(m_address, 1883);
    //client = new QMqttClient;

    //client->setHostname("iq0vkon4zrV.iot-as-mqtt.cn-shanghai.aliyuncs.com");
    client->setHostName("iq0vkon4zrV.iot-as-mqtt.cn-shanghai.aliyuncs.com");

    client->setPort(1883);
    client->setUsername("YINGJIAN&iq0vkon4zrV");
    client->setPassword("71DFCF17A69B04ADC313877FADE96E3710907C2B");
    client->setClientId("YINGJIAN|securemode=3,signmethod=hmacsha1|");
    client->connectToHost();

    QString sub="/iq0vkon4zrV/YINGJIAN/user/get";
    client->subscribe(sub);

    //connect(client,&QMqttClient::connected,this,&Widget::connectSuccessSlot);
    connect(client,SIGNAL(received(QMQTT::Message)),this,SLOT(recvMessageSlot(QMQTT::Message)));

    QSqlDatabase db=QSqlDatabase::addDatabase("QMYSQL");//加载MySQL数据库驱动
    db.setDatabaseName("mydatabase");
    db.setHostName("localhost");
    db.setUserName("root");
    db.setPassword("123456");
    db.open();

    m=new QSqlTableModel;
    m->setTable("modeldata");
    ui->tableView->setModel(m);

}

Widget::~Widget()
{


    delete ui;
}


void Widget::timerSLot()
{
    QDateTime time = QDateTime::currentDateTime();
    QString str = time.toString("yyyy-MM-dd hh:mm:ss dddd");
    ui->labelTime->setText(str);
}

void Widget::temread()
{
    QModbusReply *temreply=(QModbusReply *)(sender());
    QModbusDataUnit temunit=temreply->result();

    temreply->deleteLater();
    if(temunit.valueCount()>0){
        ui->temEdit->setText(QString::number(temunit.value(0)*0.0625));
     }

    QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
    QString msg="{\"temperature\":";
            msg+=ui->temEdit->text();
            msg+="}";
    QByteArray ba=msg.toUtf8();
    QMQTT::Message message(1,topic,ba);
    client->publish(message);
    //client->publish(topic,ba);
}

void Widget::preread()
{
    QModbusReply *prereply=(QModbusReply *)(sender());
    QModbusDataUnit preunit=prereply->result();

    prereply->deleteLater();

    if(preunit.valueCount()>0){

        ui->pressureEdit->setText(QString::number(preunit.value(0)));
     }

    QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
    QString msg="{\"pressure\":";
            msg+=ui->pressureEdit->text();
            msg+="}";
    QByteArray ba=msg.toUtf8();
    QMQTT::Message message(1,topic,ba);
    client->publish(message);
    //client->publish(topic,ba);
}
void Widget::on_readtemButton_clicked()
{
    QModbusDataUnit readtemunit(QModbusDataUnit::HoldingRegisters,0,1);
    auto temreply = modbusDevic->sendReadRequest(readtemunit,1);
    if(temreply){
        if(!temreply->isFinished()){
            connect(temreply,&QModbusReply::finished,this,&Widget::temread);
            return;
        }
        temreply->deleteLater();
    }

}


void Widget::on_readpreButton_clicked()
{
    QModbusDataUnit readpreunit(QModbusDataUnit::HoldingRegisters,1,1);
    auto prereply = modbusDevic->sendReadRequest(readpreunit,1);
    if(prereply){
        if(!prereply->isFinished()){
            connect(prereply,&QModbusReply::finished,this,&Widget::preread);
            return;
        }
        prereply->deleteLater();
    }


}

void Widget::readyread()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    if (!reply){
        return ;
    }
    QModbusDataUnit unit=reply->result();

    vector.append(unit.value(0));

    ui->temEdit->setText(QString::number(unit.value(0)*0.0625));
    ui->pressureEdit->setText(QString::number(unit.value(1)));
    ui->doorEdit->setText(QString::number(unit.value(6)));
    ui->floorEdit->setText(QString::number(unit.value(7)));
    ui->faultEdit->setText(QString::number(unit.value(8)));
    QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
    QString msg="{\"temperature\":";
            msg+=ui->temEdit->text();
            msg+=",\"pressure\":";
            msg+=ui->pressureEdit->text();
            msg+=",\"floor\":";
            msg+=ui->floorEdit->text();
            msg+=",\"open\":";
            msg+=ui->doorEdit->text();
            msg+=",\"malfunction\":";
            msg+=ui->faultEdit->text();
            msg+="}";
    QByteArray ba=msg.toUtf8();
    QMQTT::Message message(5,topic,ba);
    client->publish(message);
    //client->publish(topic,ba);

    vector.clear();

    reply->deleteLater();

}

void Widget::on_timebtnRead_clicked()
{
    m_timer->start();
}

void Widget::on_timerTimeout()
{
    QModbusDataUnit readunit(QModbusDataUnit::HoldingRegisters,0,9);
    QModbusReply *reply = modbusDevic->sendReadRequest(readunit,1);
    if(reply){
        if(!reply->isFinished()){
            connect(reply,&QModbusReply::finished,this,&Widget::readyread);
            return;
        }
        reply->deleteLater();

    }
}

void Widget::on_stopreadButton_clicked()
{
    m_timer->stop();
}

void Widget::on_connectmodelButton_clicked()
{

    if(!modbusDevic->connectDevice())
    {
        QMessageBox::warning(this,"报告","连接失败");
    }
    else
    {
        QMessageBox::information(this,"报告","连接成功");

    }
}


void Widget::on_writefloorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,2,1);
    writeunit.setValue(0,ui->controlfloorEdit->text().toUInt());
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }
}

void Widget::on_readfloorButton_clicked()
{
    QModbusDataUnit readdoorunit(QModbusDataUnit::HoldingRegisters,7,1);
    QModbusReply *doorreply = modbusDevic->sendReadRequest(readdoorunit,1);
    if(doorreply){
        if(!doorreply->isFinished()){
            connect(doorreply,&QModbusReply::finished,this,&Widget::Readfloor);

            return;
        }

        doorreply->deleteLater();
    }

}

void Widget::Readfloor()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    QModbusDataUnit unit=reply->result();
    reply->deleteLater();

    if(unit.valueCount()>0){
        ui->floorEdit->setText(QString::number(unit.value(0)));
        QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
        QString msg="{\"open\":";
                msg+=ui->floorEdit->text();
                msg+="}";
        QByteArray ba=msg.toUtf8();
        QMQTT::Message message(1,topic,ba);
        client->publish(message);
        //client->publish(topic,ba);
     }

}

void Widget::on_updownButton_clicked()
{
    if(flag_updown)
       {
           emit startcontrol();
           this->flag_updown=false;
           ui->updownButton->setText("是");
           ui->updownEdit->setText("1");
       }
       else {
           emit stopcontrol();
           this->flag_updown=true;
           ui->updownButton->setText("否");
           ui->updownEdit->setText("0");
       }
}
void Widget::startcontrol()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,3,1);
    writeunit.setValue(0,1);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }
}

void Widget::stopcontrol()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,3,1);
    writeunit.setValue(0,0);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }
}


void Widget::on_opendoorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,5,1);
    writeunit.setValue(0,1);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->controldoorEdit->setText("1");

}

void Widget::on_closedoorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,5,1);
    writeunit.setValue(0,2);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->controldoorEdit->setText("2");

}

void Widget::on_stopdoorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,5,1);
    writeunit.setValue(0,3);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->controldoorEdit->setText("3");

}

void Widget::on_upButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,4,1);
    writeunit.setValue(0,1);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->updowncontrolEdit->setText("1");
}

void Widget::on_downButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,4,1);
    writeunit.setValue(0,2);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->updowncontrolEdit->setText("2");
}

void Widget::on_stopButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,4,1);
    writeunit.setValue(0,0);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->updowncontrolEdit->setText("0");
}

void Widget::on_readdoorButton_clicked()
{
    QModbusDataUnit readunit(QModbusDataUnit::HoldingRegisters,6,1);
    QModbusReply *reply = modbusDevic->sendReadRequest(readunit,1);
    if(reply){
        if(!reply->isFinished()){
            connect(reply,&QModbusReply::finished,this,&Widget::Readdoor);

            return;
        }

        reply->deleteLater();
    }


}

void Widget::Readdoor()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    QModbusDataUnit unit=reply->result();
    reply->deleteLater();

    if(unit.valueCount()>0){
        ui->doorEdit->setText(QString::number(unit.value(0)));
        QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
        QString msg="{\"open\":";
                msg+=ui->doorEdit->text();
                msg+="}";
        QByteArray ba=msg.toUtf8();
        QMQTT::Message message(1,topic,ba);
        client->publish(message);
        //client->publish(topic,ba);
     }

}

void Widget::on_readfaultButton_clicked()
{
    QModbusDataUnit readunit(QModbusDataUnit::HoldingRegisters,8,1);
    QModbusReply *reply = modbusDevic->sendReadRequest(readunit,1);
    if(reply){
        if(!reply->isFinished()){
            connect(reply,&QModbusReply::finished,this,&Widget::Readfault);

            return;
        }

        reply->deleteLater();
    }
}

void Widget::Readfault()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    QModbusDataUnit unit=reply->result();
    reply->deleteLater();

    if(unit.valueCount()>0){
        ui->faultEdit->setText(QString::number(unit.value(0)));
        QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
        QString msg="{\"malfunction\":";
                msg+=ui->faultEdit->text();
                msg+="}";
        QByteArray ba=msg.toUtf8();
        QMQTT::Message message(1,topic,ba);
        client->publish(message);
        //client->publish(topic,ba);
     }
}

/*void Widget::on_connectserverButton_clicked()
{
    client->connectToHost();
}
void Widget::connectSuccessSlot()
{
    QMessageBox::information(this,"连接提示","连接成功");

    connect(client,&QMqttClient::messageReceived,this,&Widget::recvMessageSlot);
    connect(client,&QMqttClient::disconnected,[this]()
    {
        QMessageBox::warning(this,"连接提示","服务器断开");
    });
}*/

void Widget::recvMessageSlot(QMQTT::Message message)
{
    QByteArray pay_load=message.payload();
    ui->textEdit->setText(QString(pay_load));

    QString json_str=ui->textEdit->text();

    QJsonParseError jsonError;
    QJsonDocument doc = QJsonDocument::fromJson(pay_load, &jsonError);



    if (doc.isObject()) {
            QJsonObject object = doc.object();  // 转化为对象

            QJsonValue value = object.value("data");
            int data= value.toInt();
            QString num=QString::number(data);

            QJsonValue name = object.value("cmd");  // 获取指定 key 对应的 value
            QString cmd = name.toString();// 将 value 转化为字符串

            if(cmd=="floor"){

                ui->controlfloorEdit->setText(num);

                QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,2,1);
                writeunit.setValue(0,ui->controlfloorEdit->text().toUInt());
                QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
                if(reply){

                    reply->deleteLater();
                }
            }
            if(cmd=="control"){
                ui->updownEdit->setText(num);

                if(num=="1")
                {
                    ui->updownButton->setText("是");
                }else
                {
                    ui->updownButton->setText("否");
                }

                QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,3,1);
                writeunit.setValue(0,ui->updownEdit->text().toUInt());
                QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
                if(reply){

                    reply->deleteLater();
                }
            }
            if (cmd=="updown") {
                ui->updowncontrolEdit->setText(num);

                QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,4,1);
                writeunit.setValue(0,ui->updowncontrolEdit->text().toUInt());
                QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
                if(reply){

                    reply->deleteLater();
                }
            }
            if (cmd=="openclose") {
                ui->controldoorEdit->setText(num);

                QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,5,1);
                writeunit.setValue(0,ui->controldoorEdit->text().toUInt());
                QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
                if(reply){

                    reply->deleteLater();
                }
            }

    }


}


void Widget::on_uploadButton_clicked()
{
    QString sql=QString("insert into modeldata values('%1','%2','%3','%4','%5','%6','%7','%8','%9','%10');").arg(ui->labelTime->text()).arg(ui->temEdit->text()).arg(ui->pressureEdit->text()).arg(ui->floorEdit->text()).arg(ui->doorEdit->text()).arg(ui->faultEdit->text()).arg(ui->updownEdit->text()).arg(ui->updowncontrolEdit->text()).arg(ui->controldoorEdit->text()).arg(ui->controlfloorEdit->text());

    QSqlQuery query;
    if(query.exec(sql))
    {
        QMessageBox::information(this,"上传提示","上传成功");
    }
    else
    {
        QMessageBox::warning(this,"上传提示","上传失败");
    }
    m->select();
}

void Widget::on_timeuploadButton_clicked()
{
    a_timer->start();
}

void Widget::on_timerupload()
{
    QString sql=QString("insert into modeldata values('%1','%2','%3','%4','%5','%6','%7','%8','%9','%10');").arg(ui->labelTime->text()).arg(ui->temEdit->text()).arg(ui->pressureEdit->text()).arg(ui->floorEdit->text()).arg(ui->doorEdit->text()).arg(ui->faultEdit->text()).arg(ui->updownEdit->text()).arg(ui->updowncontrolEdit->text()).arg(ui->controldoorEdit->text()).arg(ui->controlfloorEdit->text());

    QSqlQuery query;
    query.exec(sql);
    m->select();
}

void Widget::on_stopuploadButton_clicked()
{
    a_timer->stop();
}

void Widget::on_connectmysqlButton_clicked()
{


}

void Widget::on_clearButton_clicked()
{
    QSqlQuery query;
    query.exec("delete from modeldata;");
    m->select();
}

