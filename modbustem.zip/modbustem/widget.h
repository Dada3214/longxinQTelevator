#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QModbusClient>
#include <QModbusTcpClient>
#include <QModbusReply>

#include <QTimer>
#include <QVector>
#include <QtMqtt/qmqttclient.h>

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlTableModel>

#include "mqtt/qmqtt.h"
#include <QtNetwork>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:

    void timerSLot();

    void temread();
    void preread();

    void on_readtemButton_clicked();
    void on_readpreButton_clicked();

    void on_timebtnRead_clicked();

    void on_stopreadButton_clicked();

    void on_timerTimeout();
    void on_timerupload();

    void on_connectmodelButton_clicked();

    void on_writefloorButton_clicked();


    void on_updownButton_clicked();

    void stopcontrol();
    void startcontrol();


    void on_readfloorButton_clicked();
    void Readfloor();

    void on_opendoorButton_clicked();

    void on_closedoorButton_clicked();

    void on_stopdoorButton_clicked();

    void on_readdoorButton_clicked();
    void Readdoor();

    //void connectSuccessSlot();

    void recvMessageSlot(QMQTT::Message message);

    //void on_connectserverButton_clicked();


    void on_uploadButton_clicked();

    void on_timeuploadButton_clicked();

    void on_stopuploadButton_clicked();

    void readyread();



    void on_upButton_clicked();

    void on_downButton_clicked();

    void on_stopButton_clicked();

    void on_connectmysqlButton_clicked();

    void on_clearButton_clicked();

    void on_readfaultButton_clicked();

    void Readfault();

private:

    QModbusTcpClient *modbusDevic=nullptr;

    Ui::Widget *ui;

    QTimer  *timer;
    QTimer *m_timer;
    QTimer *a_timer;

    bool flag_updown=true;

    //QMqttClient *client;
    QMQTT::Client *client;

    QVector<quint16> vector;

    QSqlTableModel *m;


};
#endif // WIDGET_H
